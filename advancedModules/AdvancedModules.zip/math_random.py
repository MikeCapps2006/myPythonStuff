import math
import random

value = 4.35

print(math.floor(value))

print(math.ceil(value))

print(round(value))

